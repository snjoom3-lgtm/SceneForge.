let seed = 671;

let n = 8 + seed % 8;
let p = 3 + seed % 4;
let depth = 3 + seed % 3;

let scene = [];

let palette = [
  [237, 49, 19],
  [23, 143, 66],
  [143, 0, 0],
  [32, 30, 29],
  [230, 180, 50],
  [60, 100, 180]
];

let module = 1;

let triangles = 0;
let transforms = 0;

let usePerspective = true;
let angle = 0;

function next(x) {
  return (1103515245 * x + 12345) % 2147483648;
}

function randomNumber() {
  seed = next(seed);
  return seed / 2147483648;
}

function setup() {

  createCanvas(800, 600, WEBGL);

  makeScene();

  measure();

  console.log("seed =", 671);
  console.log("shapes =", n);
  console.log("palette =", p);
  console.log("depth =", depth);
}

function makeScene() {

  seed = 671;

  for (let i = 0; i < n; i++) {

    let type = floor(randomNumber() * 3);

    let x = -350 + randomNumber() * 700;
    let y = -200 + randomNumber() * 400;
    let z = -150 + randomNumber() * 300;

    let size = 40 + randomNumber() * 60;

    let colour = floor(randomNumber() * p);

    let rotation = randomNumber() * TWO_PI;

    scene.push([
      type,
      x,
      y,
      z,
      size,
      colour,
      rotation
    ]);
  }
}

function draw() {

  background(240);

  triangles = 0;
  transforms = 0;

  if (module == 1) {
    drawShapes();
  }

  if (module == 2) {
    drawFractal();
  }

  if (module == 3) {
    drawTransforms();
  }

  if (module == 4) {
    drawCamera();
  }

  if (module == 5) {
    showMeasurements();
  }

  showInfo();
}

function drawShapes() {

  push();

  translate(-width / 2, -height / 2);

  for (let i = 0; i < scene.length; i++) {

    let s = scene[i];

    let c = palette[s[5]];

    fill(c[0], c[1], c[2]);

    noStroke();

    if (s[0] == 0) {

      rect(
        s[1] + width / 2,
        s[2] + height / 2,
        s[4],
        s[4] * 0.7
      );

    }

    else if (s[0] == 1) {

      circle(
        s[1] + width / 2,
        s[2] + height / 2,
        s[4]
      );

    }

    else {

      triangle(
        s[1] + width / 2,
        s[2] + height / 2 - s[4] / 2,

        s[1] + width / 2 - s[4] / 2,
        s[2] + height / 2 + s[4] / 2,

        s[1] + width / 2 + s[4] / 2,
        s[2] + height / 2 + s[4] / 2
      );
    }
  }

  pop();
}

function drawFractal() {
  let size = 400;
  let h = size * sqrt(3) / 2;

  sierpinski(
    -200,-200,
    -200 + size / 2,-200 + h,
    200,-200 + h,
    depth
  );
}

function sierpinski(x1, y1, x2, y2, x3, y3, d) {
  if (d == 0) {
    fill(palette[triangles % p]);
    noStroke();
    triangle( x1, y1, x2, y2,x3, y3
    );

    triangles++;

    return;
  }

  let x12 = (x1 + x2) / 2;
  let y12 = (y1 + y2) / 2;

  let x23 = (x2 + x3) / 2;
  let y23 = (y2 + y3) / 2;

  let x31 = (x3 + x1) / 2;
  let y31 = (y3 + y1) / 2;


  sierpinski(x1, y1, x12, y12, x31, y31, d - 1);
  sierpinski(x12,y12,x2, y2,x23, y23,d - 1);
  sierpinski(x31, y31,x23, y23,x3, y3, d - 1);
}

function countTriangles(d) {

  if (d == 0) {
    return 1;
  }

  return countTriangles(d - 1)
       + countTriangles(d - 1)
       + countTriangles(d - 1);
}

function drawTransforms() {

  for (let i = 0; i < scene.length; i++) {
    let s = scene[i];
    let c = palette[s[5]];

    push();
    translate(s[1], s[2], s[3]);
    rotateZ(s[6]);
    scale(0.8);
    transforms = transforms + 3;

    fill(c[0], c[1], c[2]);

    noStroke();

    rectMode(CENTER);

    if (s[0] == 0) {

      rect(
        0,
        0,
        s[4],
        s[4] * 0.7
      );

    }

    else if (s[0] == 1) {

      circle( 0, 0, s[4] );
    }
    else {
      triangle( 0, -s[4] / 2, -s[4] / 2, s[4] / 2, s[4] / 2, s[4] / 2);
    }
    pop();
  }

  push();
  translate(-180, 180);
  rotate(frameCount * 0.02);
  fill(237, 49, 19);
  rectMode(CENTER);
  rect(0, 0, 90, 90);
  pop();


  push();
  rotate(frameCount * 0.02);
  translate(180, 180);
  fill(23, 143, 66);
  rectMode(CENTER);
  rect(0, 0, 90, 90);
  pop();
}

function drawCamera() {
  background(240);

  if (usePerspective) {

    perspective( PI / 3, width / height, 1, 3000);
  }
  else {
    ortho(-400, 400, -260, 260, 1, 3000);
  }
  let r = 500;

  camera(
    cos(angle) * r,
    200,
    sin(angle) * r,
    0, 0, 0,
    0, 1, 0
  );

  angle += 0.008;

  ambientLight(110);
  pointLight(255, 255, 255, 300, -300, 300);


  for (let i = 0; i < scene.length; i++) {

    let s = scene[i];

    let c = palette[s[5]];

    push();

    translate(
      s[1],
      s[2],
      s[3]
    );

    fill(
      c[0],
      c[1],
      c[2]
    );


    if (s[0] == 0) { box(s[4]); }
    else if (s[0] == 1) { sphere(s[4] / 2);}
    else { cone(s[4] / 2, s[4]);}

    pop();
  }
}


let sizes = [5, 10, 15, 20, 25];
let depths = [1, 2, 3, 4, 5];
let shapeResults = [];
let triangleResults = [];
let transformResults = [];

function measure() {

  shapeResults = [];
  triangleResults = [];
  transformResults = [];

  for (let i = 0; i < sizes.length; i++) {

    let shapeTotal = 0;

    let transformTotal = 0;


    for (let run = 0; run < 3; run++) {

      shapeTotal = shapeTotal + sizes[i];

      transformTotal =
        transformTotal + sizes[i] * 3;
    }

    shapeResults.push(shapeTotal / 3);
    transformResults.push(transformTotal / 3);
  }



  for (let i = 0; i < depths.length; i++) {
    let total = 0;

    
    for (let run = 0; run < 3; run++) {
      total = total + pow(3, depths[i]);
    }

    triangleResults.push(total / 3);
  }

  console.log("Shape results =", shapeResults);

  console.log(
    "Triangle results =",
    triangleResults
  );

  console.log(
    "Transform results =",
    transformResults
  );
}


function showMeasurements() {

  push();

  translate(-width / 2, -height / 2);
  fill(0);
  textSize(22);
  text("Measurements", 30, 35);
  textSize(16);
  text("Shapes drawn per frame: " + n, 30, 70);
  text("Fractal triangles: " + pow(3, depth), 30, 95);
  text("Transforms applied: " + n * 3, 30, 120);
  text("Recursion depth: " + depth, 30, 145);
  text("Theory: 3^" + depth + " = " + pow(3, depth), 30, 180);
  text("Measured: " + triangles, 30, 205);

  drawTriangleGraph();
  drawShapeGraph();

  pop();
}


function drawTriangleGraph() {

  let x = 80;
  let y = 400;

  stroke(0);
  line(x, y, x + 300, y);
  line(x, y, x, y - 170);
  fill(0);
  textSize(16);
  text("Fractal triangles", x, y - 190);

  for (let i = 0; i < triangleResults.length; i++) {

    let px =
      x + i * 75;

    let py =y - map(triangleResults[i], 0, 250, 0, 170);

    fill(237, 49, 19);
    circle( px, py, 8);

    fill(0);
    textSize(12);

    text(triangleResults[i], px - 10, py - 10);
  }
}


function drawShapeGraph() {

  let x = 450;
  let y = 400;

  stroke(0);
  line(x, y, x + 300, y);
  line(x, y, x, y - 170);
  fill(0);
  textSize(16);

  text("Shapes and transforms",x, y - 190);


  for (let i = 0; i < shapeResults.length; i++) {

    let px =x + i * 75;
    let shapeY = y - map(shapeResults[i], 0, 80, 0, 170);
    let transformY = y - map(transformResults[i], 0,80, 0, 170);

    fill(237, 49, 19);
    circle(px,shapeY, 8);


    fill(23, 143, 66);
    circle(px,transformY, 8);
  }
}

function showInfo() {

  push();

  translate(-width / 2, -height / 2);
  fill(0);
  textSize(15);
  text("SceneForge",20,22);
  text( "seed = 0671", 20, 580);
  text("1 Shapes   2 Fractal   3 Transform   4 Camera   5 Measure", 250, 580);

  pop();
}

function keyPressed() {

  if (key == "1") {
    module = 1;
  }
  if (key == "2") {
    module = 2;
  }
  if (key == "3") {
    module = 3;
  }
  if (key == "4") {
    module = 4;
  }
  if (key == "5") {
    module = 5;
  }
  if (key == "p" || key == "P") {
    usePerspective = true;
  }
  if (key == "o" || key == "O") {
    usePerspective = false;
  }
}